<!-- resources/views/barang/delete.blade.php -->

<h1>Hapus Barang</h1>

<p>Anda yakin ingin menghapus barang dengan nama: {{ $barang->NamaBarang }}?</p>

<form action="{{ route('barang.destroy', $barang->id) }}" method="post">
    @csrf
    @method('DELETE')
    <button type="submit">Hapus Barang</button>
</form>
