<!-- resources/views/barang/index.blade.php -->

<h1>Daftar Barang</h1>

<!-- Tampilkan daftar barang -->
@foreach ($barangs as $barang)
    <p>{{ $barang->NamaBarang }} - {{ $barang->HargaSatuan }} - {{ $barang->Stok }}</p>
@endforeach

<!-- resources/views/barang/index.blade.php -->

<h1>Daftar Barang</h1>

<a href="{{ route('barang.create') }}">Tambah Barang</a>

@foreach ($barangs as $barang)
    <p>{{ $barang->NamaBarang }} - {{ $barang->HargaSatuan }} - {{ $barang->Stok }}
        <a href="{{ route('barang.edit', $barang->id) }}">Edit</a>
        <a href="{{ route('barang.destroy', $barang->id) }}">Hapus</a>
    </p>
@endforeach
