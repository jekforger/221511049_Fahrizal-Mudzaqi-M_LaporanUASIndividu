<!-- resources/views/barang/create.blade.php -->

<h1>Tambah Barang</h1>

<!-- Formulir tambah barang -->
<form action="{{ route('barang.store') }}" method="post">
    @csrf
    <label for="NamaBarang">Nama Barang:</label>
    <input type="text" name="NamaBarang" required>
    <label for="HargaSatuan">Harga Satuan:</label>
    <input type="number" name="HargaSatuan" required>
    <label for="Stok">Stok:</label>
    <input type="number" name="Stok" required>
    <button type="submit">Tambah Barang</button>
</form>

<!-- resources/views/barang/index.blade.php -->

<h1>Daftar Barang</h1>

<a href="{{ route('barang.create') }}">Tambah Barang</a>

<table>
    <thead>
        <tr>
            <th>Nama Barang</th>
            <th>Harga Satuan</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($barangs as $barang)
            <tr>
                <td>{{ $barang->NamaBarang }}</td>
                <td>{{ $barang->HargaSatuan }}</td>
                <td>{{ $barang->Stok }}</td>
                <td>
                    <a href="{{ route('barang.edit', $barang->id) }}">Edit</a>
                    <a href="{{ route('barang.destroy', $barang->id) }}">Hapus</a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
