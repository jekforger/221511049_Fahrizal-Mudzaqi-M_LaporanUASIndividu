<!-- resources/views/nota/index.blade.php -->

<h1>Daftar Nota</h1>

<!-- Tampilkan daftar nota -->
@foreach ($notas as $nota)
    <p>Nota {{ $nota->KodeNota }} - Total: {{ $nota->Total }}</p>
@endforeach
