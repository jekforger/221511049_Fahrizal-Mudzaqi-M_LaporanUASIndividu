<!-- resources/views/nota/detail.blade.php -->

<h1>Detail Nota</h1>

<!-- Tampilkan detail nota -->
<p>Nota {{ $nota->KodeNota }} - Tanggal: {{ $nota->TglNota }}</p>
<!-- Tampilkan barang dan jumlah yang dibeli -->
@foreach ($barangNota as $item)
    <p>{{ $item->NamaBarang }} - {{ $item->JumlahBarang }} - {{ $item->HargaSatuan * $item->JumlahBarang }}</p>
@endforeach
<p>Total Belanja: {{ $nota->Total }}</p>
