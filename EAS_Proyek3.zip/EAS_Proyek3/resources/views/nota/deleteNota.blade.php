<!-- resources/views/nota/delete.blade.php -->

<h1>Hapus Nota</h1>

<p>Anda yakin ingin menghapus nota dengan kode: {{ $nota->KodeNota }}?</p>

<form action="{{ route('nota.destroy', $nota->id) }}" method="post">
    @csrf
    @method('DELETE')
    <button type="submit">Hapus Nota</button>
</form>
