<!-- resources/views/tenan/delete.blade.php -->

<h1>Hapus Tenan</h1>

<p>Anda yakin ingin menghapus tenan dengan nama: {{ $tenan->NamaTenan }}?</p>

<form action="{{ route('tenan.destroy', $tenan->id) }}" method="post">
    @csrf
    @method('DELETE')
    <button type="submit">Hapus Tenan</button>
</form>
