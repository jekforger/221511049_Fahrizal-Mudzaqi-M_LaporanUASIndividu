<!-- resources/views/tenan/edit.blade.php -->

<h1>Edit Tenan</h1>

<!-- Formulir edit tenan -->
<form action="{{ route('tenan.update', $tenan->id) }}" method="post">
    @csrf
    @method('PUT')
    <label for="NamaTenan">Nama Tenan:</label>
    <input type="text" name="NamaTenan" value="{{ $tenan->NamaTenan }}" required>
    <label for="HP">Nomor HP:</label>
    <input type="text" name="HP" value="{{ $tenan->HP }}" required>
    <button type="submit">Simpan Perubahan</button>
</form>
