<!-- resources/views/tenan/create.blade.php -->

<h1>Tambah Tenan</h1>

<!-- Formulir tambah tenan -->
<form action="{{ route('tenan.store') }}" method="post">
    @csrf
    <label for="NamaTenan">Nama Tenan:</label>
    <input type="text" name="NamaTenan" required>
    <label for="HP">Nomor HP:</label>
    <input type="text" name="HP" required>
    <button type="submit">Tambah Tenan</button>
</form>
