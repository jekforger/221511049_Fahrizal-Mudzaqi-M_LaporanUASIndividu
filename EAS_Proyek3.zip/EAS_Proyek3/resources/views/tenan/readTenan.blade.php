<!-- resources/views/tenan/index.blade.php -->

<h1>Daftar Tenan</h1>

<!-- Tampilkan daftar tenan -->
@foreach ($tenans as $tenan)
    <p>{{ $tenan->NamaTenan }} - {{ $tenan->HP }}</p>
@endforeach
