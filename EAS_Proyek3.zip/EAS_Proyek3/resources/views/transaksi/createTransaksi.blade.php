<!-- resources/views/transaksi/tambah.blade.php -->

<h1>Tambah Transaksi</h1>

<!-- Formulir tambah transaksi -->
<form action="{{ route('transaksi.store') }}" method="post">
    @csrf
    <label for="KodeTenan">Pilih Tenan:</label>
    <select name="KodeTenan" required>
        @foreach ($tenans as $tenan)
            <option value="{{ $tenan->id }}">{{ $tenan->NamaTenan }}</option>
        @endforeach
    </select>
    <!-- Tambahkan input untuk barang, jumlah, dan lainnya sesuai kebutuhan -->
    <button type="submit">Tambah Transaksi</button>
</form>
