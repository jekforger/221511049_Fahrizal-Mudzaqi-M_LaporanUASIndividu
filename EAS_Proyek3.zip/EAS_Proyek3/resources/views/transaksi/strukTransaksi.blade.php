<!-- resources/views/transaksi/struk.blade.php -->

<h1>Struk Transaksi</h1>

<!-- Tampilkan informasi struk -->
<p>Nomor Nota: {{ $nota->KodeNota }}</p>
<p>Tanggal: {{ $nota->TglNota }}</p>
<p>Total Belanja: {{ $nota->Total }}</p>
<!-- Tampilkan barang dan jumlah yang dibeli -->
@foreach ($barangNota as $item)
    <p>{{ $item->NamaBarang }} - {{ $item->JumlahBarang }} - {{ $item->HargaSatuan * $item->JumlahBarang }}</p>
@endforeach
