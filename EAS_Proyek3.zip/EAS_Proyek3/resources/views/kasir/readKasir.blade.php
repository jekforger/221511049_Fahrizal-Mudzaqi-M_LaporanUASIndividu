<!-- resources/views/kasir/index.blade.php -->

<h1>Daftar Kasir</h1>

<!-- Tampilkan daftar kasir -->
@foreach ($kasiRs as $kasir)
    <p>{{ $kasir->Nama }} - {{ $kasir->HP }}</p>
@endforeach
