<!-- resources/views/kasir/edit.blade.php -->

<h1>Edit Kasir</h1>

<!-- Formulir edit kasir -->
<form action="{{ route('kasir.update', $kasir->id) }}" method="post">
    @csrf
    @method('PUT')
    <label for="Nama">Nama Kasir:</label>
    <input type="text" name="Nama" value="{{ $kasir->Nama }}" required>
    <label for="HP">Nomor HP:</label>
    <input type="text" name="HP" value="{{ $kasir->HP }}" required>
    <button type="submit">Simpan Perubahan</button>
</form>
