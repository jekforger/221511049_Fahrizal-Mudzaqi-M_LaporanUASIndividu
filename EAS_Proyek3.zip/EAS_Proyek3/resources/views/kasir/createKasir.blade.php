<!-- resources/views/kasir/create.blade.php -->

<h1>Tambah Kasir</h1>

<!-- Formulir tambah kasir -->
<form action="{{ route('kasir.store') }}" method="post">
    @csrf
    <label for="Nama">Nama Kasir:</label>
    <input type="text" name="Nama" required>
    <label for="HP">Nomor HP:</label>
    <input type="text" name="HP" required>
    <button type="submit">Tambah Kasir</button>
</form>
