<!-- resources/views/kasir/delete.blade.php -->

<h1>Hapus Kasir</h1>

<p>Anda yakin ingin menghapus kasir dengan nama: {{ $kasir->Nama }}?</p>

<form action="{{ route('kasir.destroy', $kasir->id) }}" method="post">
    @csrf
    @method('DELETE')
    <button type="submit">Hapus Kasir</button>
</form>
