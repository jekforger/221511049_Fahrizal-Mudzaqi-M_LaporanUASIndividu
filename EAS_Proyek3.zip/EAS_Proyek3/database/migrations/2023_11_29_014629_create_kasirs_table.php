<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateKasirsTable extends Migration
{
    public function up()
    {
        Schema::create('kasirs', function (Blueprint $table) {
            $table->id();
            $table->string('KodeKasir');
            $table->string('NamaKasir');
            $table->string('NoHp');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('kasirs');
    }
};
