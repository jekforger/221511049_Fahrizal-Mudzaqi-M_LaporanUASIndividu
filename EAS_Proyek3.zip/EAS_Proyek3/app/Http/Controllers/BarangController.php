<?php

namespace App\Http\Controllers;

// app/Http/Controllers/BarangController.php

use App\Models\Barang;
use Illuminate\Http\Request;

class BarangController extends Controller
{
    public function read()
    {
        $barangs = Barang::all();
        return view('barang.read', compact('barangs'));
    }

    public function create()
    {
        return view('barang.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'NamaBarang' => 'required|string|max:255',
            'HargaSatuan' => 'required|numeric',
            'Stok' => 'required|integer',
        ]);

        Barang::create($request->all());

        return redirect()->route('barang.read')->with('success', 'Barang berhasil ditambahkan');
    }

    public function edit(Barang $barang)
    {
        return view('barang.edit', compact('barang'));
    }

    public function update(Request $request, Barang $barang)
    {
        $request->validate([
            'NamaBarang' => 'required|string|max:255',
            'HargaSatuan' => 'required|numeric',
            'Stok' => 'required|integer',
        ]);

        $barang->edit($request->all());

        return redirect()->route('barang.read')->with('success', 'Barang berhasil diperbarui');
    }

    public function destroy(Barang $barang)
    {
        $barang->delete();

        return redirect()->route('barang.index')->with('success', 'Barang berhasil dihapus');
    }
}


